import java.util.List;

public class Bidder_adapter extends Bidder_template {
    private static final double learningRate = 0.5;

    @Override
    public void strategize(List<Double> bids, int myBid, double myPayment, int currentDay) {
        if (IWon(myPayment)) {
            factor *= (1 - learningRate);
        } else {
            factor *= (1 + learningRate);
        }
    }

//    public static double standardGaussian(double x) {
//        return Math.exp(-x*x / 2) / Math.sqrt(2 * Math.PI);
//    }
//
//    // return pdf(x, mu, signma) = Gaussian pdf with mean mu and stddev sigma
//    public static double gaussian(double x, double mu, double sigma) {
//        return standardGaussian((x - mu) / sigma) / sigma;
//    }
}
