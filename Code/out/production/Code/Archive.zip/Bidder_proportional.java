import java.util.List;

public class Bidder_proportional extends Bidder_template {

    @Override
    public void strategize(List<Double> bids, int myBid, double myPayment, int currentDay) {
        factor = 0.7 * currentDay / Auctioneer.defaultConfig.getDays();
    }
}
