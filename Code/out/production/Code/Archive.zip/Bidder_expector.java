import java.util.List;

public class Bidder_expector extends Bidder_template {

    @Override
    public double getBid(double v) {
        return Math.min(averageTopBids[5], v);
    }

    @Override
    public void strategize(List<Double> bids, int myBid, double myPayment, int currentDay) {
    }
}
